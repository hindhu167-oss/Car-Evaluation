# Car Evaluation using Machine Learning

## Project Description
This project predicts the acceptability of a car using the UCI Car Evaluation dataset.

The six input features are:
- Buying price
- Maintenance cost
- Number of doors
- Number of persons the car can carry
- Luggage boot size
- Safety

The target classes are:
- unacc = Unacceptable
- acc = Acceptable
- good = Good
- vgood = Very Good

## Technology Used
- Python
- Pandas
- Scikit-learn
- Decision Tree Classifier
- Tkinter GUI

## Project Structure
Car-Evaluation-Final/
- dataset/
  - car.data
  - car.names
  - car.c45-names
- model/
  - car_evaluation_model.pkl
- train_model.py
- app.py
- requirements.txt
- README.md

## How to Run in Visual Studio

1. Open the `Car-Evaluation-Final` folder in Visual Studio.
2. Make sure Python is installed and select the Python environment.
3. Open the Terminal.
4. Install packages:

   pip install -r requirements.txt

5. Train the model:

   python train_model.py

6. Start the application:

   python app.py

7. Select all six car details and click `EVALUATE CAR`.

## Machine Learning Workflow
Dataset -> Data Loading -> Train/Test Split -> One-Hot Encoding -> Decision Tree Training -> Evaluation -> Saved Model -> GUI Prediction

## Important Note
This project predicts car acceptability, not the market price of a car.
