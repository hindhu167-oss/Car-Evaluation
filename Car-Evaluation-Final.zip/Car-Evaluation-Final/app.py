import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
import pickle
from pathlib import Path

BASE = Path(__file__).resolve().parent
MODEL_PATH = BASE / "model" / "car_evaluation_model.pkl"

with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

OPTIONS = {
    "Buying Price": ["vhigh", "high", "med", "low"],
    "Maintenance": ["vhigh", "high", "med", "low"],
    "Doors": ["2", "3", "4", "5more"],
    "Persons": ["2", "4", "more"],
    "Luggage Boot": ["small", "med", "big"],
    "Safety": ["low", "med", "high"],
}

FEATURES = ["buying", "maintenance", "doors", "persons", "lug_boot", "safety"]

def evaluate_car():
    values = [combos[name].get() for name in OPTIONS]

    if any(v == "" for v in values):
        messagebox.showwarning("Missing Information", "Please select all car details.")
        return

    row = pd.DataFrame([values], columns=FEATURES)
    result = model.predict(row)[0]

    names = {
        "unacc": "UNACCEPTABLE",
        "acc": "ACCEPTABLE",
        "good": "GOOD",
        "vgood": "VERY GOOD"
    }

    messagebox.showinfo(
        "Car Evaluation Result",
        f"Predicted Evaluation:\n\n{names.get(result, result.upper())}"
    )

root = tk.Tk()
root.title("Car Evaluation using Machine Learning")
root.geometry("560x560")
root.resizable(False, False)

title = tk.Label(
    root, text="CAR EVALUATION SYSTEM",
    font=("Arial", 20, "bold")
)
title.pack(pady=(25, 5))

subtitle = tk.Label(
    root, text="Machine Learning based car acceptability prediction",
    font=("Arial", 10)
)
subtitle.pack(pady=(0, 20))

frame = tk.Frame(root)
frame.pack(padx=45, fill="x")

combos = {}

for i, (label, values) in enumerate(OPTIONS.items()):
    tk.Label(frame, text=label, font=("Arial", 11)).grid(
        row=i, column=0, sticky="w", pady=8
    )
    combo = ttk.Combobox(frame, values=values, state="readonly", width=22)
    combo.grid(row=i, column=1, padx=20, pady=8)
    combos[label] = combo

button = tk.Button(
    root,
    text="EVALUATE CAR",
    command=evaluate_car,
    font=("Arial", 12, "bold"),
    padx=20,
    pady=10
)
button.pack(pady=30)

footer = tk.Label(
    root,
    text="Classes: Unacceptable | Acceptable | Good | Very Good",
    font=("Arial", 9)
)
footer.pack()

root.mainloop()
