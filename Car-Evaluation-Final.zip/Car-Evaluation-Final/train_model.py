import pandas as pd
import pickle
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

BASE = Path(__file__).resolve().parent
DATA = BASE / "dataset" / "car.data"
MODEL_DIR = BASE / "model"
MODEL_DIR.mkdir(exist_ok=True)

columns = [
    "buying", "maintenance", "doors",
    "persons", "lug_boot", "safety", "class"
]

df = pd.read_csv(DATA, names=columns)

X = df.drop("class", axis=1)
y = df["class"]

categorical_features = X.columns.tolist()

preprocessor = ColumnTransformer(
    transformers=[
        ("categorical", OneHotEncoder(handle_unknown="ignore"),
         categorical_features)
    ]
)

# A decision tree is easy to understand and works well with categorical features
# after one-hot encoding.
model = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", DecisionTreeClassifier(
        criterion="entropy",
        max_depth=8,
        random_state=42
    ))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

model.fit(X_train, y_train)
pred = model.predict(X_test)

accuracy = accuracy_score(y_test, pred)

print("=" * 55)
print("CAR EVALUATION - MODEL TRAINING")
print("=" * 55)
print(f"Dataset records : {len(df)}")
print(f"Training records: {len(X_train)}")
print(f"Testing records : {len(X_test)}")
print(f"Accuracy        : {accuracy * 100:.2f}%")
print("\nClassification Report:")
print(classification_report(y_test, pred, zero_division=0))
print("Confusion Matrix:")
print(confusion_matrix(y_test, pred))

model_path = MODEL_DIR / "car_evaluation_model.pkl"
with open(model_path, "wb") as f:
    pickle.dump(model, f)

print(f"\nModel saved to: {model_path}")
